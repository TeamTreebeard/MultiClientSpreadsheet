/*
Filename: CircularException.h
Authors: Brady Mathews, Christyn Phillippi, Kevin Faustino, Brandon Hilton
Last Modified: 4/25/2015

Header file containing the declarations for the circular exception.
*/

#ifndef CIRCULAREXCEPTION_H
#define CIRCULAREXCEPTION_H

class CircularException
{
	public:
	CircularException()
	{}
	~CircularException()
	{}
};

#endif