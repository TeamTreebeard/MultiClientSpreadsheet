To start the server enter make run from the directory containing the server files. 
An executable will be created called server.
Run the executable with an optional parameter for the port number. 
If no port number is given, it will default to port 2000.

