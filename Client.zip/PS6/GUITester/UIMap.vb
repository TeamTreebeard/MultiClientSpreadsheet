﻿Imports System
Imports System.Collections.Generic
Imports System.CodeDom.Compiler
Imports Microsoft.VisualStudio.TestTools.UITest.Extension
Imports Microsoft.VisualStudio.TestTools.UITesting
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard
Imports Mouse = Microsoft.VisualStudio.TestTools.UITesting.Mouse
Imports MouseButtons = System.Windows.Forms.MouseButtons
Imports System.Drawing
Imports System.Windows.Input
Imports System.Text.RegularExpressions

Namespace GUITester
    
    Partial Public Class UIMap
    End Class
End Namespace
